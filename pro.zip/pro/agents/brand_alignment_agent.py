"""
agents/brand_alignment_agent.py
--------------------------------
Agent 3 — Brand Alignment Agent for MarketMind AI.
 
Role: Ensures all strategy and messaging output is fully consistent with the
      company's brand identity, tone of voice, and knowledge base before it
      reaches the Content Agent.
 
Responsibilities
~~~~~~~~~~~~~~~~
* Retrieves the GTM strategy from ChromaDB (Agent 2 output).
* Audits the strategy against the company's brand_voice, product positioning,
  and past marketing history stored in the CompanyProfile.
* Identifies any misalignments, off-brand language, or positioning gaps.
* Produces a brand-aligned, compliance-checked version of the strategy with
  explicit brand guardrails for the Content Agent.
* Persists the aligned document into the ``brand_alignment`` ChromaDB collection.
"""
 
from __future__ import annotations
 
import uuid
 
from openai import OpenAI
from pydantic import BaseModel, Field
 
from agents.research_agent import CompanyProfile
from database_setup import get_icp_and_strategy_collection, get_brand_alignment_collection
 
 
# ---------------------------------------------------------------------------
# Pydantic schema
# ---------------------------------------------------------------------------
 
 
class BrandAlignmentReport(BaseModel):
    """Output of the Brand Alignment Agent audit and refinement pass."""
 
    alignment_summary: str = Field(
        ...,
        description=(
            "One-paragraph summary of overall brand alignment quality: what was "
            "on-brand, what was adjusted, and the rationale for each change."
        ),
    )
    brand_voice_guidelines: str = Field(
        ...,
        description=(
            "Explicit do/don't writing guidelines distilled from the brand_voice "
            "profile for the Content Agent to follow strictly."
        ),
    )
    aligned_messaging_pillars: list[str] = Field(
        ...,
        description=(
            "The messaging pillars from the GTM strategy, refined to use language "
            "and tone that precisely matches the company's brand voice."
        ),
    )
    aligned_value_proposition: str = Field(
        ...,
        description=(
            "The value proposition statement rewritten in the company's exact "
            "brand voice and terminology."
        ),
    )
    content_guardrails: list[str] = Field(
        ...,
        description=(
            "Explicit rules the Content Agent must follow. Includes brand tone "
            "rules AND mandatory safety guardrails: no offensive, political, "
            "discriminatory, religious, or inappropriate content of any kind."
        ),
    )
    brand_approved_strategy: str = Field(
        ...,
        description=(
            "The complete GTM strategy text after brand alignment edits, ready "
            "to be passed directly to the Content Agent."
        ),
    )
 
 
# ---------------------------------------------------------------------------
# Agent class
# ---------------------------------------------------------------------------
 
 
class BrandAlignmentAgent:
    """Agent 3 — Brand consistency and compliance specialist.
 
    Backstory:
        You are a Senior Brand Strategist and Compliance Officer with 10 years
        of experience ensuring that marketing output for global B2B brands is
        consistently on-message, culturally appropriate, and fully compliant
        with professional communication standards. You have deep expertise in
        brand identity management, tone-of-voice governance, and marketing
        compliance across regulated and culturally sensitive markets, including
        the Middle East. You are the final quality gate before any content
        reaches a copywriter — nothing passes through you unless it is
        precisely on-brand and unambiguously safe.
 
    Goal:
        Audit the GTM strategy for brand consistency. Refine all language to
        match the company's defined brand voice exactly. Produce explicit
        content guardrails that the Content Agent must follow, ensuring all
        generated copy is professional, compliant, business-focused, and free
        from any offensive, political, discriminatory, or inappropriate content.
    """
 
    CHAT_MODEL: str      = "gpt-4o-mini"
    EMBEDDING_MODEL: str = "text-embedding-3-small"
 
    def __init__(self, openai_client: OpenAI) -> None:
        self.openai_client     = openai_client
        self.strategy_collection  = get_icp_and_strategy_collection()
        self.alignment_collection = get_brand_alignment_collection()
 
    # ------------------------------------------------------------------
    # ChromaDB retrieval
    # ------------------------------------------------------------------
 
    def fetch_strategy(self, strategy_doc_id: str) -> str:
        """Retrieve the GTM strategy document from ChromaDB."""
        result = self.strategy_collection.get(
            ids=[strategy_doc_id],
            include=["documents"],
        )
        if not result["documents"] or not result["documents"][0]:
            raise ValueError(
                f"Strategy document '{strategy_doc_id}' not found in ChromaDB. "
                "Ensure the Strategy Agent completed successfully."
            )
        return result["documents"][0]
 
    # ------------------------------------------------------------------
    # Brand alignment audit
    # ------------------------------------------------------------------
 
    def run_brand_alignment(
        self,
        profile: CompanyProfile,
        strategy_text: str,
    ) -> BrandAlignmentReport:
        """Audit and refine the GTM strategy for brand consistency and safety.
 
        Args:
            profile: The CompanyProfile containing brand_voice and product data.
            strategy_text: The full GTM strategy from Agent 2.
 
        Returns:
            A BrandAlignmentReport with the aligned strategy and content guardrails.
        """
        system_prompt = (
            "You are a Senior Brand Strategist and Compliance Officer responsible for "
            "ensuring all marketing strategy and content output is:\n"
            "  1. Precisely on-brand — language, tone, and terminology match the "
            "     company's defined brand voice exactly.\n"
            "  2. Professionally appropriate — suitable for senior B2B decision-makers "
            "     in the Middle East and GCC markets.\n"
            "  3. Fully compliant — free from any offensive, political, religious, "
            "     discriminatory, controversial, or inappropriate content.\n\n"
            "Your output drives the Content Agent's guardrails. Be specific, "
            "actionable, and unambiguous in every guideline you produce."
        )
 
        user_prompt = (
            f"Company: {profile.company_name}\n"
            f"Products & Pricing: {profile.products_and_prices}\n"
            f"Brand Voice Definition: {profile.brand_voice}\n"
            f"Past Marketing History: {profile.past_successful_marketing}\n\n"
            "TASK: Perform a full brand alignment audit of the GTM strategy below.\n\n"
            "Step 1 — ALIGNMENT SUMMARY:\n"
            "Assess overall brand alignment. Note what was already on-brand and "
            "what required adjustment. Be specific about language and tone changes.\n\n"
            "Step 2 — BRAND VOICE GUIDELINES:\n"
            "Distil the brand_voice definition into concrete do/don't writing rules "
            "for a copywriter. Include: preferred vocabulary, sentence structure, "
            "formality level, use of data/statistics, emotional vs rational tone, "
            "and any industry-specific language conventions.\n\n"
            "Step 3 — ALIGNED MESSAGING PILLARS:\n"
            "Rewrite the strategy's messaging pillars using language that precisely "
            "matches the brand voice. Every pillar must sound authentically on-brand.\n\n"
            "Step 4 — ALIGNED VALUE PROPOSITION:\n"
            "Rewrite the value proposition in the company's exact brand voice and "
            "terminology. It must resonate with GCC B2B buyers.\n\n"
            "Step 5 — CONTENT GUARDRAILS:\n"
            "Produce a numbered list of explicit rules for the Content Agent. "
            "These rules must cover BOTH brand guidelines AND the following mandatory "
            "safety requirements:\n"
            "  - PROHIBITED: Any content that is offensive, discriminatory, or "
            "    derogatory toward any group, nationality, religion, or gender.\n"
            "  - PROHIBITED: Any political commentary, opinions on government policy, "
            "    or references to geopolitical conflicts.\n"
            "  - PROHIBITED: Any religious commentary, endorsement, or critique.\n"
            "  - PROHIBITED: Any content that could be considered culturally "
            "    insensitive or inappropriate in the GCC/Middle East context.\n"
            "  - PROHIBITED: Any unverified statistical claims or misleading data.\n"
            "  - PROHIBITED: Any content that is sexually suggestive, violent, "
            "    or otherwise inappropriate for a professional business audience.\n"
            "  - REQUIRED: All copy must be factual, professional, and business-focused.\n"
            "  - REQUIRED: All claims must be supportable and non-defamatory.\n\n"
            "Step 6 — BRAND-APPROVED STRATEGY:\n"
            "Produce the complete GTM strategy text with all brand alignment edits "
            "applied. This is the version passed directly to the Content Agent.\n\n"
            f"GTM Strategy to Audit:\n{strategy_text}"
        )
 
        completion = self.openai_client.beta.chat.completions.parse(
            model=self.CHAT_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_prompt},
            ],
            response_format=BrandAlignmentReport,
            max_tokens=3000,
        )
        return completion.choices[0].message.parsed
 
    # ------------------------------------------------------------------
    # Embedding & persistence
    # ------------------------------------------------------------------
 
    def embed_text(self, text: str) -> list[float]:
        response = self.openai_client.embeddings.create(
            model=self.EMBEDDING_MODEL, input=text
        )
        return response.data[0].embedding
 
    def persist_alignment(
        self,
        profile: CompanyProfile,
        alignment_report: BrandAlignmentReport,
        strategy_doc_id: str,
    ) -> str:
        """Persist the brand-aligned strategy into ChromaDB.
 
        Returns:
            The ChromaDB document ID.
        """
        doc_id    = f"brand_{uuid.uuid4().hex}"
        embedding = self.embed_text(alignment_report.brand_approved_strategy)
 
        # Store the full alignment report as JSON-serialisable metadata fields
        guardrails_str = " | ".join(alignment_report.content_guardrails)
        pillars_str    = " | ".join(alignment_report.aligned_messaging_pillars)
 
        self.alignment_collection.upsert(
            ids=[doc_id],
            embeddings=[embedding],
            documents=[alignment_report.brand_approved_strategy],
            metadatas=[{
                "company_name":           profile.company_name,
                "brand_voice":            profile.brand_voice,
                "alignment_summary":      alignment_report.alignment_summary[:500],
                "brand_voice_guidelines": alignment_report.brand_voice_guidelines[:500],
                "content_guardrails":     guardrails_str[:1000],
                "aligned_value_prop":     alignment_report.aligned_value_proposition[:500],
                "messaging_pillars":      pillars_str[:500],
                "source_strategy_doc_id": strategy_doc_id,
                "agent":                  "brand_alignment",
            }],
        )
        return doc_id
 
    # ------------------------------------------------------------------
    # Primary entry point
    # ------------------------------------------------------------------
 
    def run(
        self,
        profile: CompanyProfile,
        strategy_doc_id: str,
    ) -> tuple[BrandAlignmentReport, str]:
        """Execute the full Brand Alignment Agent pipeline.
 
        Returns:
            (BrandAlignmentReport, brand_doc_id)
        """
        strategy_text    = self.fetch_strategy(strategy_doc_id)
        alignment_report = self.run_brand_alignment(profile, strategy_text)
        brand_doc_id     = self.persist_alignment(profile, alignment_report, strategy_doc_id)
        return alignment_report, brand_doc_id
