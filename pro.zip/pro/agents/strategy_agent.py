"""
agents/strategy_agent.py
------------------------
Agent 2 — Strategy Agent for MarketMind AI.
 
Role: Defines positioning, ICP, messaging framework, and channel strategy.
 
Responsibilities
~~~~~~~~~~~~~~~~
* Retrieves the market research report from ChromaDB (Agent 1 output).
* Defines a professional, firmographic Ideal Customer Profile (ICP) based on
  company size, industry sector, job titles, pain points, and behavioural
  traits. No fictional names, random handles, or fabricated personas.
* Architects a localised Middle East GTM strategy with positioning, messaging
  pillars, and a prioritised channel plan.
* Persists the ICP + strategy document into the ``icp_and_strategy`` collection.
"""
 
from __future__ import annotations
 
import uuid
 
from openai import OpenAI
from pydantic import BaseModel, Field
 
from agents.research_agent import CompanyProfile
from database_setup import get_market_research_collection, get_icp_and_strategy_collection
 
 
# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------
 
 
class ICPSegment(BaseModel):
    """A single, professionally defined Ideal Customer Profile segment."""
 
    segment_name: str = Field(
        ..., description="Descriptive label for the segment (e.g., 'Mid-Market CFOs in KSA')."
    )
    firmographics: str = Field(
        ...,
        description=(
            "Company-level attributes: industry sector(s), employee count range, "
            "annual revenue band, geographic concentration within the GCC."
        ),
    )
    job_titles: list[str] = Field(
        ...,
        description=(
            "Specific decision-maker and influencer job titles targeted "
            "(e.g., 'Chief Financial Officer', 'VP of Operations', 'IT Director')."
        ),
    )
    pain_points: list[str] = Field(
        ...,
        description="Top three to five professional pain points this segment experiences.",
    )
    behavioural_traits: str = Field(
        ...,
        description=(
            "How this segment researches, evaluates, and buys: preferred channels, "
            "content formats, trust signals, and decision timeline."
        ),
    )
    value_drivers: str = Field(
        ...,
        description="The primary business outcomes this segment seeks from a solution.",
    )
 
 
class GTMStrategyDocument(BaseModel):
    """Structured GTM strategy output from Agent 2."""
 
    executive_summary: str = Field(..., description="One-paragraph strategic intent.")
    icp_segments: list[ICPSegment] = Field(
        ..., description="Two to three professionally defined ICP segments."
    )
    value_proposition: str = Field(
        ..., description="Localised value proposition statement for the GCC market."
    )
    messaging_pillars: list[str] = Field(
        ..., description="Three to five core messaging themes for Middle Eastern B2B buyers."
    )
    channel_strategy: str = Field(
        ..., description="Prioritised channel plan with rationale for each channel."
    )
    past_marketing_scaled: str = Field(
        ...,
        description=(
            "Explicit analysis of which past marketing successes transfer to the "
            "Middle East context and exactly how each will be localised and amplified."
        ),
    )
    execution_roadmap: str = Field(
        ..., description="90-day phased execution plan with monthly deliverables."
    )
    kpis: list[str] = Field(
        ..., description="Quantifiable KPIs for each phase of the roadmap."
    )
    risk_mitigation: str = Field(
        ..., description="Key regional risks and specific contingency actions."
    )
 
 
# ---------------------------------------------------------------------------
# Agent class
# ---------------------------------------------------------------------------
 
 
class StrategyAgent:
    """Agent 2 — Positioning, ICP, messaging, and channel strategy specialist.
 
    Backstory:
        You are a Senior Go-To-Market Strategist with 12 years of experience
        launching and scaling B2B products across Saudi Arabia, the UAE, and
        broader GCC markets. You have led GTM strategy for Fortune 500
        companies entering the region and for regional champions expanding
        internationally. Your hallmark is building strategies grounded in
        real firmographic data, genuine buyer psychology, and culturally
        intelligent positioning — never generic templates or fictional personas.
 
    Goal:
        Produce a precise, actionable GTM strategy that defines exactly who
        the ideal customer is (by company type, role, and pain point), how to
        position the product for maximum resonance in the GCC, and which
        channels will deliver the highest-quality pipeline.
    """
 
    CHAT_MODEL: str      = "gpt-4o-mini"
    EMBEDDING_MODEL: str = "text-embedding-3-small"
 
    def __init__(self, openai_client: OpenAI) -> None:
        self.openai_client      = openai_client
        self.research_collection = get_market_research_collection()
        self.strategy_collection = get_icp_and_strategy_collection()
 
    # ------------------------------------------------------------------
    # ChromaDB retrieval
    # ------------------------------------------------------------------
 
    def fetch_research(self, research_doc_id: str) -> str:
        """Retrieve the market research document from ChromaDB."""
        result = self.research_collection.get(
            ids=[research_doc_id],
            include=["documents"],
        )
        if not result["documents"] or not result["documents"][0]:
            raise ValueError(
                f"Research document '{research_doc_id}' not found. "
                "Ensure the Research Agent completed successfully."
            )
        return result["documents"][0]
 
    # ------------------------------------------------------------------
    # ICP + strategy generation
    # ------------------------------------------------------------------
 
    def generate_strategy(
        self,
        profile: CompanyProfile,
        research_report: str,
    ) -> GTMStrategyDocument:
        """Generate the ICP definitions and full GTM strategy document.
 
        ICP segments are defined exclusively using firmographics, job titles,
        pain points, and behavioural traits. No fictional names, random social
        media handles, or invented personas are generated.
        """
        past_marketing_note = (
            f"Past Successful Marketing to Scale:\n{profile.past_successful_marketing}"
            if profile.past_successful_marketing != "No past marketing specific plans provided."
            else "No prior marketing history provided — build strategy from first principles."
        )
 
        system_prompt = (
            "You are a Senior Go-To-Market Strategist with deep expertise in the Middle "
            "East and GCC B2B markets. You build strategies grounded in real firmographic "
            "data and genuine buyer psychology.\n\n"
            "CRITICAL ICP RULES — you must follow these without exception:\n"
            "- Define ICP segments using ONLY: industry sectors, company size, revenue "
            "  bands, job titles, pain points, and behavioural traits.\n"
            "- DO NOT generate fictional character names, random social media handles, "
            "  invented personal backgrounds, or made-up individual personas.\n"
            "- Every ICP segment must describe a class of buyers, not a fictional person."
        )
 
        user_prompt = (
            f"Company: {profile.company_name}\n"
            f"Products & Pricing: {profile.products_and_prices}\n"
            f"Brand Voice: {profile.brand_voice}\n"
            f"{past_marketing_note}\n\n"
            "Using the market research below, produce a complete Middle East GTM strategy "
            "with the following elements:\n\n"
            "EXECUTIVE SUMMARY: One paragraph stating the core strategic intent and "
            "primary market opportunity.\n\n"
            "ICP SEGMENTS (2–3 segments): For each segment provide:\n"
            "  - Segment name (descriptive label, e.g. 'Enterprise IT Directors in UAE')\n"
            "  - Firmographics (sector, company size, revenue band, GCC geography)\n"
            "  - Job titles (specific decision-maker and influencer titles)\n"
            "  - Pain points (3–5 specific professional challenges)\n"
            "  - Behavioural traits (how they research, evaluate, and buy)\n"
            "  - Value drivers (what business outcomes they seek)\n\n"
            "VALUE PROPOSITION: A single localised statement for the GCC market.\n\n"
            "MESSAGING PILLARS: 3–5 core themes that will resonate with GCC B2B buyers.\n\n"
            "CHANNEL STRATEGY: Prioritised channels (LinkedIn, Instagram, Google, events, "
            "WhatsApp Business, Snapchat) with specific rationale for each.\n\n"
            "SCALING PAST SUCCESSES: Analyse each past marketing action. State explicitly "
            "which tactics transfer to the Middle East, how each will be localised, and "
            "what adaptations are required for GCC cultural and market norms.\n\n"
            "90-DAY ROADMAP: Month 1, Month 2, Month 3 with specific deliverables per month.\n\n"
            "KPIs: Quantifiable targets for each phase (e.g., 'Month 1: 500 LinkedIn "
            "profile views from target job titles in UAE/KSA').\n\n"
            "RISK MITIGATION: Top 3 regional risks with specific contingency actions.\n\n"
            f"Market Research:\n{research_report}"
        )
 
        completion = self.openai_client.beta.chat.completions.parse(
            model=self.CHAT_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_prompt},
            ],
            response_format=GTMStrategyDocument,
            max_tokens=3000,
        )
        return completion.choices[0].message.parsed
 
    # ------------------------------------------------------------------
    # Serialise strategy to readable text
    # ------------------------------------------------------------------
 
    @staticmethod
    def strategy_to_text(doc: GTMStrategyDocument) -> str:
        """Convert a GTMStrategyDocument into a formatted plain-text string."""
        lines: list[str] = []
 
        lines.append("# MIDDLE EAST GTM STRATEGY\n")
        lines.append("## Executive Summary")
        lines.append(doc.executive_summary)
 
        lines.append("\n## Ideal Customer Profile (ICP) Segments")
        for i, seg in enumerate(doc.icp_segments, 1):
            lines.append(f"\n### ICP Segment {i}: {seg.segment_name}")
            lines.append(f"**Firmographics:** {seg.firmographics}")
            lines.append(f"**Job Titles:** {', '.join(seg.job_titles)}")
            lines.append("**Pain Points:**")
            for pp in seg.pain_points:
                lines.append(f"  - {pp}")
            lines.append(f"**Behavioural Traits:** {seg.behavioural_traits}")
            lines.append(f"**Value Drivers:** {seg.value_drivers}")
 
        lines.append("\n## Localised Value Proposition")
        lines.append(doc.value_proposition)
 
        lines.append("\n## Messaging Pillars")
        for i, pillar in enumerate(doc.messaging_pillars, 1):
            lines.append(f"  {i}. {pillar}")
 
        lines.append("\n## Channel Strategy")
        lines.append(doc.channel_strategy)
 
        lines.append("\n## Scaling Past Marketing Successes")
        lines.append(doc.past_marketing_scaled)
 
        lines.append("\n## 90-Day Execution Roadmap")
        lines.append(doc.execution_roadmap)
 
        lines.append("\n## KPIs & Success Metrics")
        for kpi in doc.kpis:
            lines.append(f"  - {kpi}")
 
        lines.append("\n## Risk Mitigation")
        lines.append(doc.risk_mitigation)
 
        return "\n".join(lines)
 
    # ------------------------------------------------------------------
    # Embedding & persistence
    # ------------------------------------------------------------------
 
    def embed_text(self, text: str) -> list[float]:
        response = self.openai_client.embeddings.create(
            model=self.EMBEDDING_MODEL, input=text
        )
        return response.data[0].embedding
 
    def persist_strategy(
        self,
        profile: CompanyProfile,
        strategy_text: str,
        research_doc_id: str,
    ) -> str:
        """Persist the strategy document into the icp_and_strategy collection."""
        doc_id    = f"strategy_{uuid.uuid4().hex}"
        embedding = self.embed_text(strategy_text)
 
        self.strategy_collection.upsert(
            ids=[doc_id],
            embeddings=[embedding],
            documents=[strategy_text],
            metadatas=[{
                "company_name":              profile.company_name,
                "brand_voice":               profile.brand_voice,
                "products_and_prices":       profile.products_and_prices,
                "past_successful_marketing": profile.past_successful_marketing,
                "source_research_doc_id":    research_doc_id,
                "region":                    "Middle East",
                "agent":                     "strategy",
            }],
        )
        return doc_id
 
    # ------------------------------------------------------------------
    # Primary entry point
    # ------------------------------------------------------------------
 
    def run(
        self,
        profile: CompanyProfile,
        research_doc_id: str,
    ) -> tuple[str, str]:
        """Execute the full Strategy Agent pipeline.
 
        Returns:
            (strategy_text, strategy_doc_id)
        """
        research_report = self.fetch_research(research_doc_id)
        strategy_doc    = self.generate_strategy(profile, research_report)
        strategy_text   = self.strategy_to_text(strategy_doc)
        strategy_doc_id = self.persist_strategy(profile, strategy_text, research_doc_id)
        return strategy_text, strategy_doc_id
