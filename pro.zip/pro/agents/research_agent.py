"""
agents/research_agent.py
------------------------
Agent 1 — Research Agent for MarketMind AI.
 
Role: Performs market, competitor, and trend analysis for the Middle East region.
 
Responsibilities
~~~~~~~~~~~~~~~~
* Accepts a CompanyProfile (manual entry or PDF extraction).
* Executes live Tavily web searches scoped to the Middle East / GCC market.
* Synthesises findings into a structured market research report covering the
  competitive landscape, audience segments, channel data, and growth trends.
* Persists the report and its OpenAI embedding into the ``market_research``
  ChromaDB collection.
 
No input() calls exist in this module — all interactivity is owned by app.py.
"""
 
from __future__ import annotations
 
import uuid
 
from openai import OpenAI
from pydantic import BaseModel, Field
from tavily import TavilyClient
 
from database_setup import get_market_research_collection
from utils.security import sanitize_for_query, validate_input_text
 
 
# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------
 
 
class CompanyProfile(BaseModel):
    """Structured representation of a client's company profile."""
 
    company_name: str = Field(..., description="Full legal or trading name of the company.")
    products_and_prices: str = Field(
        ..., description="Descriptions of products/services and their pricing."
    )
    brand_voice: str = Field(
        ...,
        description=(
            "A description of the brand's tone and communication style "
            "(e.g., 'professional yet approachable', 'bold and disruptive')."
        ),
    )
    past_successful_marketing: str = Field(
        default="No past marketing specific plans provided.",
        description=(
            "Optional summary of previously executed marketing campaigns "
            "or initiatives that generated positive results."
        ),
    )
 
 
# ---------------------------------------------------------------------------
# Agent class
# ---------------------------------------------------------------------------
 
 
class ResearchAgent:
    """Agent 1 — Market, competitor, and trend analysis specialist.
 
    Backstory:
        You are a Principal Market Intelligence Analyst with 15 years of
        experience in the Middle East and GCC markets. Your expertise spans
        B2B and B2C sector research, competitive landscaping, consumer
        behaviour analysis, and digital channel benchmarking across Saudi
        Arabia, UAE, Qatar, Kuwait, Bahrain, and Oman. You produce rigorous,
        evidence-based research reports that senior leadership teams use to
        make high-stakes market entry and expansion decisions.
 
    Goal:
        Deliver a comprehensive, data-grounded market research report that
        reveals the true opportunity landscape, competitive dynamics, and
        audience profile for the client's business in the Middle East.
    """
 
    EMBEDDING_MODEL: str = "text-embedding-3-small"
    CHAT_MODEL: str = "gpt-4o-mini"
 
    def __init__(self, openai_client: OpenAI, tavily_client: TavilyClient) -> None:
        self.openai_client = openai_client
        self.tavily_client = tavily_client
        self.collection = get_market_research_collection()
 
    # ------------------------------------------------------------------
    # Profile parsing
    # ------------------------------------------------------------------
 
    def parse_profile_from_text(self, extracted_text: str) -> CompanyProfile:
        """Extract a CompanyProfile from raw PDF text using the LLM."""
        prompt = (
            "Extract the following details from the text and return them as a "
            "structured company profile:\n\n"
            f"{extracted_text}\n\n"
            "Fields: company_name, products_and_prices, brand_voice, "
            "past_successful_marketing. Use 'Not specified' for missing fields."
        )
        completion = self.openai_client.beta.chat.completions.parse(
            model=self.CHAT_MODEL,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a business analyst. Extract structured company "
                        "profile information precisely from the provided text."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            response_format=CompanyProfile,
        )
        return completion.choices[0].message.parsed
 
    # ------------------------------------------------------------------
    # Search query construction
    # ------------------------------------------------------------------
 
    def build_search_queries(self, profile: CompanyProfile) -> list[str]:
        """Construct Tavily-safe queries scoped to the Middle East market.
 
        Hard-sliced to 250 characters to stay within Tavily's 400-char limit.
        """
        company  = sanitize_for_query(profile.company_name, max_chars=60)
        products = sanitize_for_query(profile.products_and_prices, max_chars=80)
 
        raw_queries = [
            f"{company} market opportunity Middle East GCC 2024",
            f"{products} B2B demand Saudi Arabia UAE market",
            f"{company} competitors Middle East market landscape analysis",
            f"digital marketing trends Middle East B2B enterprise 2024",
            f"GCC consumer behaviour e-commerce technology adoption 2024",
            f"{products} industry growth trends Gulf region 2024",
        ]
        return [q[:250] for q in raw_queries]
 
    # ------------------------------------------------------------------
    # Tavily web search
    # ------------------------------------------------------------------
 
    def run_tavily_search(self, queries: list[str]) -> str:
        """Execute searches and return concatenated snippet context."""
        all_results: list[str] = []
        for query in queries:
            try:
                results = self.tavily_client.search(
                    query=query, search_depth="advanced", max_results=5
                )
                for result in results.get("results", []):
                    snippet = result.get("content", "")
                    if snippet:
                        all_results.append(snippet[:500])
            except Exception as exc:  # noqa: BLE001
                all_results.append(f"[Search warning: {exc}]")
 
        if not all_results:
            return (
                "No live search results retrieved. Generate a comprehensive "
                "Middle East market analysis from parametric knowledge."
            )
        return "\n\n---\n\n".join(all_results)
 
    # ------------------------------------------------------------------
    # Report synthesis
    # ------------------------------------------------------------------
 
    def synthesise_report(self, profile: CompanyProfile, context: str) -> str:
        """Synthesise Tavily context into a structured market research report."""
        system_prompt = (
            "You are a Principal Market Intelligence Analyst specialising in the "
            "Middle East and Gulf Cooperation Council (GCC) region. You produce "
            "rigorous, evidence-based, and actionable market research reports used "
            "by senior leadership to make high-stakes expansion decisions. Your "
            "analysis integrates market sizing, competitive dynamics, audience "
            "profiling, and channel intelligence."
        )
        user_prompt = (
            f"Company: {profile.company_name}\n"
            f"Products & Pricing: {profile.products_and_prices}\n"
            f"Brand Voice: {profile.brand_voice}\n\n"
            "Using the retrieved market intelligence below, produce a comprehensive "
            "Middle East Market Research Report with the following sections:\n\n"
            "## 1. Market Landscape Overview\n"
            "   - Market size, growth rate, and key macroeconomic drivers in the GCC.\n"
            "   - Regulatory and cultural considerations relevant to this business.\n\n"
            "## 2. Competitive Landscape\n"
            "   - Direct and indirect competitors operating in the Middle East.\n"
            "   - Their positioning, pricing, and perceived strengths/weaknesses.\n"
            "   - Identifiable market gaps and white-space opportunities.\n\n"
            "## 3. Target Audience Segments\n"
            "   - Two to three primary audience segments defined by industry sector, "
            "     company size, and decision-making role.\n"
            "   - Key psychographic and behavioural characteristics per segment.\n\n"
            "## 4. Cultural & Consumer Behaviour Insights\n"
            "   - Communication preferences, trust signals, and purchase drivers "
            "     specific to GCC business buyers.\n\n"
            "## 5. Digital Channel Intelligence\n"
            "   - Platform usage data (LinkedIn, Instagram, Snapchat, X, Google, "
            "     WhatsApp Business) among B2B audiences in the region.\n"
            "   - Content format preferences and peak engagement patterns.\n\n"
            "## 6. Key Opportunities & Risks\n"
            "   - Top three opportunities with supporting evidence.\n"
            "   - Top three risks with likelihood and potential impact.\n\n"
            "## 7. Strategic Implications\n"
            "   - Prioritised recommendations for market entry or expansion.\n\n"
            f"Retrieved Market Intelligence:\n{context}"
        )
 
        response = self.openai_client.chat.completions.create(
            model=self.CHAT_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.35,
            max_tokens=2000,
        )
        return response.choices[0].message.content.strip()
 
    # ------------------------------------------------------------------
    # Embedding & persistence
    # ------------------------------------------------------------------
 
    def embed_text(self, text: str) -> list[float]:
        response = self.openai_client.embeddings.create(
            model=self.EMBEDDING_MODEL, input=text
        )
        return response.data[0].embedding
 
    def persist_research(self, profile: CompanyProfile, research_report: str) -> str:
        """Embed and upsert the research report into ChromaDB.
 
        Returns:
            The ChromaDB document ID.
        """
        doc_id    = f"research_{uuid.uuid4().hex}"
        embedding = self.embed_text(research_report)
 
        self.collection.upsert(
            ids=[doc_id],
            embeddings=[embedding],
            documents=[research_report],
            metadatas=[{
                "company_name":             profile.company_name,
                "brand_voice":              profile.brand_voice,
                "products_and_prices":      profile.products_and_prices,
                "past_successful_marketing": profile.past_successful_marketing,
                "agent":                    "research",
            }],
        )
        return doc_id
