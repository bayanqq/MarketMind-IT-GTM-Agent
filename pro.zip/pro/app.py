"""
app.py
------
MarketMind AI — Streamlit Web Interface (4-Agent Pipeline).

Pipeline:
  Agent 1: Research Agent       — market, competitor, trend analysis
  Agent 2: Strategy Agent       — ICP, positioning, messaging, channels
  Agent 3: Brand Alignment Agent — brand consistency + content guardrails
  Agent 4: Content Agent        — social posts, email, ad copy

State machine for Stage 1:
  substage = "form"    → show profile form
  substage = "hitl"    → HITL approval gate
  substage = "running" → execute pipeline, then advance to stage 2

Run with:
    streamlit run app.py
"""

from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI
from tavily import TavilyClient

from agents.brand_alignment_agent import BrandAlignmentAgent, BrandAlignmentReport
from agents.content_agent import ContentAgent, ContentPackage
from agents.research_agent import CompanyProfile, ResearchAgent
from agents.strategy_agent import StrategyAgent
from utils.pdf_handler import load_and_validate_pdf
from utils.security import validate_input_text

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="MarketMind AI",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# CSS
# ---------------------------------------------------------------------------
st.markdown("""
<style>
:root {
    --mm-primary:#1B4FE4; --mm-accent:#00C2A8; --mm-dark:#0D1B2A;
    --mm-surface:#F4F7FF; --mm-border:#D6E0F5; --mm-success:#16A34A;
}
[data-testid="stSidebar"]   { background:var(--mm-dark); }
[data-testid="stSidebar"] * { color:#E2E8F0 !important; }
[data-testid="stSidebar"] .stMarkdown h2 {
    color:var(--mm-accent) !important; font-size:.85rem;
    letter-spacing:.12em; text-transform:uppercase;
}
.stage-pill { display:inline-block; padding:4px 14px; border-radius:20px;
    font-size:.75rem; font-weight:700; letter-spacing:.06em;
    text-transform:uppercase; margin-bottom:6px; }
.pill-pending { background:#E2E8F0; color:#64748B; }
.pill-active  { background:#EFF6FF; color:var(--mm-primary); border:1px solid var(--mm-primary); }
.pill-done    { background:#DCFCE7; color:var(--mm-success); }
.post-card { border-left:4px solid var(--mm-primary); background:#fff;
    border-radius:0 10px 10px 0; padding:18px 22px; margin-bottom:16px;
    box-shadow:0 1px 4px rgba(27,79,228,.08); }
.ad-card { border-left:4px solid var(--mm-accent); background:#fff;
    border-radius:0 10px 10px 0; padding:18px 22px; margin-bottom:16px;
    box-shadow:0 1px 4px rgba(0,194,168,.08); }
.platform-tag { font-size:.7rem; font-weight:700; text-transform:uppercase;
    letter-spacing:.1em; color:var(--mm-primary); margin-bottom:8px; }
.email-preview { background:#fff; border:1px solid var(--mm-border);
    border-radius:10px; padding:28px 32px; font-family:Georgia,serif; line-height:1.75; }
.email-subject { font-size:1.15rem; font-weight:700; color:var(--mm-dark); margin-bottom:4px; }
.email-preview-text { font-size:.82rem; color:#94A3B8; margin-bottom:20px; font-style:italic; }
.email-cta { display:inline-block; margin-top:16px; padding:12px 28px;
    background:var(--mm-primary); color:#fff !important;
    border-radius:6px; font-weight:700; font-size:.9rem; }
.guardrail-item { background:#FEF3C7; border-left:3px solid #F59E0B;
    padding:6px 12px; margin-bottom:4px; border-radius:0 4px 4px 0;
    font-size:.82rem; }
.mm-divider { border:none; border-top:1px solid var(--mm-border); margin:28px 0; }
#MainMenu,footer { visibility:hidden; }
.block-container { padding-top:2rem; }
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# Session-state defaults
# ---------------------------------------------------------------------------
DEFAULTS: dict = {
    "stage":    1,
    "substage": "form",   # "form" | "hitl" | "running"
    # Agent outputs
    "profile":           None,
    "research_report":   None,
    "research_doc_id":   None,
    "gtm_strategy":      None,
    "strategy_doc_id":   None,
    "alignment_report":  None,
    "brand_doc_id":      None,
    "content_package":   None,
    "content_doc_id":    None,
    # Form values
    "form_company_name":   "",
    "form_products":       "",
    "form_brand_voice":    "",
    "form_past_marketing": "",
    "form_pdf_text":       "",
    # API keys
    "openai_key": "",
    "tavily_key": "",
}
for k, v in DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ---------------------------------------------------------------------------
# Client factory
# ---------------------------------------------------------------------------
@st.cache_resource(show_spinner=False)
def get_clients(openai_key: str, tavily_key: str):
    return OpenAI(api_key=openai_key), TavilyClient(api_key=tavily_key)

def resolve_clients():
    load_dotenv()
    ok = st.session_state.openai_key or os.getenv("OPENAI_API_KEY", "")
    tk = st.session_state.tavily_key or os.getenv("TAVILY_API_KEY", "")
    if not ok or not tk:
        st.error("⚠️ API keys missing — enter them in the sidebar and click **Save Keys**.")
        st.stop()
    return get_clients(ok, tk)

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
def render_sidebar() -> None:
    with st.sidebar:
        st.markdown(
            "<h1 style='color:#00C2A8;font-size:1.4rem;font-weight:800;"
            "letter-spacing:.04em;margin-bottom:0'>🧠 MarketMind AI</h1>"
            "<p style='font-size:.78rem;color:#94A3B8;margin-top:2px'>"
            "Agentic Marketing Intelligence · Middle East GTM</p>",
            unsafe_allow_html=True,
        )
        st.divider()
        st.markdown("## Pipeline")
        current = st.session_state.stage
        for num, title, subtitle in [
            (1, "🔍 Research Agent",        "Market & Competitor Analysis"),
            (2, "🗺️ Strategy Agent",        "ICP, Positioning & Channels"),
            (3, "🎨 Brand Alignment Agent", "Brand Consistency & Guardrails"),
            (4, "✍️ Content Agent",          "Posts, Email & Ad Copy"),
        ]:
            if current > num:
                pill = '<span class="stage-pill pill-done">✓ Complete</span>'
            elif current == num:
                pill = '<span class="stage-pill pill-active">▶ Active</span>'
            else:
                pill = '<span class="stage-pill pill-pending">Pending</span>'
            st.markdown(
                f"{pill}<br><span style='font-weight:700;font-size:.9rem'>{title}</span>"
                f"<br><span style='font-size:.76rem;color:#94A3B8'>{subtitle}</span>",
                unsafe_allow_html=True,
            )
            st.markdown("<div style='margin-bottom:12px'></div>", unsafe_allow_html=True)

        st.divider()
        st.markdown("## API Configuration")
        load_dotenv()
        ok_val = st.text_input("OpenAI API Key",
            value=st.session_state.openai_key or os.getenv("OPENAI_API_KEY",""),
            type="password", placeholder="sk-…")
        tv_val = st.text_input("Tavily API Key",
            value=st.session_state.tavily_key or os.getenv("TAVILY_API_KEY",""),
            type="password", placeholder="tvly-…")
        if st.button("💾 Save Keys", use_container_width=True):
            if ok_val and tv_val:
                st.session_state.openai_key = ok_val
                st.session_state.tavily_key = tv_val
                st.success("API keys saved.")
            else:
                st.error("Both keys are required.")
        has_keys = bool(
            (st.session_state.openai_key or os.getenv("OPENAI_API_KEY","")) and
            (st.session_state.tavily_key or os.getenv("TAVILY_API_KEY",""))
        )
        st.markdown(
            f"<span style='color:{'#16A34A' if has_keys else '#DC2626'};font-size:.8rem'>"
            f"{'● API keys loaded' if has_keys else '● No API keys detected'}</span>",
            unsafe_allow_html=True,
        )
        st.divider()
        if st.button("🔄 Reset Pipeline", use_container_width=True):
            for k, v in DEFAULTS.items():
                st.session_state[k] = v
            st.rerun()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def hr():
    st.markdown('<hr class="mm-divider">', unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# Stage 1a — Profile form
# ---------------------------------------------------------------------------
def render_form() -> None:
    st.markdown("## 🔍 Stage 1 — Research Agent")
    st.caption("Provide your company profile. The agent will run live Middle East "
               "market and competitor research, then feed results into the pipeline.")
    hr()

    profile_source = st.radio("Input method:", ["✏️ Manual Entry", "📄 Upload PDF"], horizontal=True)
    pdf_text = ""
    if profile_source == "📄 Upload PDF":
        uploaded = st.file_uploader("Upload company profile PDF", type=["pdf"])
        if uploaded:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                tmp.write(uploaded.read())
                tmp_path = tmp.name
            with st.spinner("Extracting PDF text…"):
                pdf_text = load_and_validate_pdf(tmp_path) or ""
            Path(tmp_path).unlink(missing_ok=True)
            if pdf_text:
                st.success(f"PDF parsed — {len(pdf_text)} characters extracted.")
                with st.expander("Preview extracted text"):
                    st.text(pdf_text[:600] + ("…" if len(pdf_text) > 600 else ""))
            else:
                st.error("Could not extract text — please use manual entry.")

    hr()
    with st.form("profile_form"):
        c1, c2 = st.columns(2)
        with c1:
            company_name = st.text_input("Company Name *",
                placeholder="e.g. Acme Technologies MENA")
            brand_voice  = st.text_area("Brand Voice / Tone *", height=120,
                placeholder="e.g. Professional yet approachable, data-driven, empowering")
        with c2:
            products  = st.text_area("Products / Services & Pricing *", height=120,
                placeholder="e.g. SaaS HR platform — Starter $49/mo, Pro $149/mo")
            past_mkt  = st.text_area("Past Successful Marketing (optional)", height=120,
                placeholder="e.g. LinkedIn thought-leadership series drove 3× pipeline in Q3 2023")
        submitted = st.form_submit_button(
            "Next: Review & Approve Search →", type="primary", use_container_width=True
        )

    if not submitted:
        return

    errors: list[str] = []
    using_pdf = bool(profile_source == "📄 Upload PDF" and pdf_text)
    if not using_pdf:
        if not company_name.strip(): errors.append("Company Name is required.")
        if not products.strip():     errors.append("Products / Services is required.")
        if not brand_voice.strip():  errors.append("Brand Voice is required.")
    for label, val in [("Company Name", company_name), ("Products", products), ("Brand Voice", brand_voice)]:
        if val.strip() and not validate_input_text(val):
            errors.append(f"'{label}' contains potentially unsafe content.")
    if past_mkt.strip() and not validate_input_text(past_mkt):
        errors.append("'Past Marketing' contains potentially unsafe content.")
    if errors:
        for e in errors: st.error(e)
        return

    st.session_state.form_company_name   = company_name
    st.session_state.form_products       = products
    st.session_state.form_brand_voice    = brand_voice
    st.session_state.form_past_marketing = past_mkt
    st.session_state.form_pdf_text       = pdf_text
    st.session_state.substage            = "hitl"
    st.rerun()

# ---------------------------------------------------------------------------
# Stage 1b — HITL gate
# ---------------------------------------------------------------------------
def render_hitl() -> None:
    st.markdown("## 🔍 Stage 1 — Research Agent")
    hr()
    name = st.session_state.form_company_name or "Company (from PDF)"
    st.success(f"✅ Profile saved for: **{name}**")
    st.markdown("### 🔐 Human-in-the-Loop Approval Required")
    st.info(
        "The next step calls the **Tavily Search API** to gather live Middle East "
        "market and competitor intelligence. This will consume API credits.\n\n"
        f"**Company:** {name}\n\n"
        "Approve to launch the full 4-agent pipeline, or edit your profile."
    )
    c1, c2, _ = st.columns([1, 1, 4])
    with c1:
        if st.button("✅ Approve & Run", type="primary", use_container_width=True):
            st.session_state.substage = "running"
            st.rerun()
    with c2:
        if st.button("✏️ Edit Profile", use_container_width=True):
            st.session_state.substage = "form"
            st.rerun()

# ---------------------------------------------------------------------------
# Stage 1c — Execute Research Agent
# ---------------------------------------------------------------------------
def run_research_pipeline() -> None:
    st.markdown("## 🔍 Stage 1 — Research Agent Running…")
    hr()

    openai_client, tavily_client = resolve_clients()
    agent = ResearchAgent(openai_client=openai_client, tavily_client=tavily_client)

    pdf_text     = st.session_state.form_pdf_text
    company_name = st.session_state.form_company_name
    products     = st.session_state.form_products
    brand_voice  = st.session_state.form_brand_voice
    past_mkt     = st.session_state.form_past_marketing

    bar    = st.progress(0, text="Step 1/4 — Building company profile…")
    status = st.empty()

    try:
        # Step 1: Profile
        if pdf_text:
            status.info("Parsing company profile from PDF via LLM…")
            profile = agent.parse_profile_from_text(pdf_text)
            if company_name.strip(): profile.company_name        = company_name.strip()
            if brand_voice.strip():  profile.brand_voice         = brand_voice.strip()
            if products.strip():     profile.products_and_prices = products.strip()
        else:
            profile = CompanyProfile(
                company_name=company_name.strip(),
                products_and_prices=products.strip(),
                brand_voice=brand_voice.strip(),
                past_successful_marketing=(
                    past_mkt.strip() if past_mkt.strip()
                    else "No past marketing specific plans provided."
                ),
            )
        bar.progress(10, text="Step 2/4 — Running Tavily market research searches…")

        # Step 2: Tavily searches
        queries  = agent.build_search_queries(profile)
        snippets: list[str] = []
        for i, q in enumerate(queries):
            status.info(f"Searching ({i+1}/{len(queries)}): {q[:65]}…")
            try:
                res = tavily_client.search(q, search_depth="advanced", max_results=5)
                for r in res.get("results", []):
                    s = r.get("content", "")
                    if s: snippets.append(s[:500])
            except Exception as exc:
                status.warning(f"Search note: {exc}")
            bar.progress(10 + int((i+1) / len(queries) * 40),
                         text=f"Step 2/4 — Searching ({i+1}/{len(queries)})…")

        context = "\n\n---\n\n".join(snippets) if snippets else (
            "No live results retrieved. Generating from parametric knowledge.")

        # Step 3: Synthesise report
        bar.progress(55, text="Step 3/4 — Synthesising market research report…")
        status.info("Synthesising research report…")
        research_report = agent.synthesise_report(profile, context)

        # Step 4: Persist
        bar.progress(90, text="Step 4/4 — Persisting to ChromaDB…")
        status.info("Saving research to ChromaDB…")
        research_doc_id = agent.persist_research(profile, research_report)

        bar.progress(100, text="✓ Research Agent complete!")
        status.empty()
        time.sleep(0.3)

        st.session_state.profile         = profile
        st.session_state.research_report = research_report
        st.session_state.research_doc_id = research_doc_id
        st.session_state.substage        = "form"
        st.session_state.stage           = 2
        st.rerun()

    except Exception as exc:
        bar.empty(); status.empty()
        st.error(f"❌ Research Agent error: {exc}")
        st.exception(exc)
        if st.button("← Go back"):
            st.session_state.substage = "hitl"
            st.rerun()

# ---------------------------------------------------------------------------
# Shared result expanders
# ---------------------------------------------------------------------------
def render_research_summary() -> None:
    profile: CompanyProfile = st.session_state.profile
    with st.expander("📋 Company Profile", expanded=False):
        c1, c2 = st.columns(2)
        c1.markdown(f"**Company:** {profile.company_name}")
        c1.markdown(f"**Brand Voice:** {profile.brand_voice}")
        c2.markdown(f"**Products & Pricing:** {profile.products_and_prices}")
        c2.markdown(f"**Past Marketing:** {profile.past_successful_marketing}")
    with st.expander("📊 Market Research Report", expanded=False):
        st.markdown(st.session_state.research_report)

def render_strategy_summary() -> None:
    with st.expander("🗺️ GTM Strategy (ICP + Positioning)", expanded=False):
        st.markdown(st.session_state.gtm_strategy)

def render_alignment_summary() -> None:
    report: BrandAlignmentReport = st.session_state.alignment_report
    with st.expander("🎨 Brand Alignment Report", expanded=False):
        st.markdown(f"**Summary:** {report.alignment_summary}")
        st.markdown(f"**Value Proposition:** {report.aligned_value_proposition}")
        st.markdown("**Content Guardrails Applied:**")
        for g in report.content_guardrails:
            st.markdown(
                f'<div class="guardrail-item">🛡️ {g}</div>',
                unsafe_allow_html=True,
            )

# ---------------------------------------------------------------------------
# Stage 2 — Strategy Agent
# ---------------------------------------------------------------------------
def render_stage_2() -> None:
    st.markdown("## 🗺️ Stage 2 — Strategy Agent")
    st.caption("Defining ICP segments (firmographics, job titles, pain points, "
               "behavioural traits), positioning, messaging pillars, and channel strategy.")
    hr()
    render_research_summary()
    hr()
    if st.button("🗺️ Generate ICP & GTM Strategy", type="primary"):
        openai_client, _ = resolve_clients()
        with st.spinner("Building ICP and GTM strategy…"):
            try:
                agent = StrategyAgent(openai_client=openai_client)
                gtm_strategy, strategy_doc_id = agent.run(
                    profile=st.session_state.profile,
                    research_doc_id=st.session_state.research_doc_id,
                )
                st.session_state.gtm_strategy    = gtm_strategy
                st.session_state.strategy_doc_id = strategy_doc_id
                st.session_state.stage           = 3
                st.rerun()
            except Exception as exc:
                st.error(f"❌ Strategy Agent error: {exc}")
                st.exception(exc)

# ---------------------------------------------------------------------------
# Stage 3 — Brand Alignment Agent
# ---------------------------------------------------------------------------
def render_stage_3() -> None:
    st.markdown("## 🎨 Stage 3 — Brand Alignment Agent")
    st.caption("Auditing the GTM strategy for brand consistency, refining all "
               "language to match your brand voice, and generating content guardrails.")
    hr()
    render_research_summary()
    render_strategy_summary()
    hr()
    if st.button("🎨 Run Brand Alignment", type="primary"):
        openai_client, _ = resolve_clients()
        with st.spinner("Running brand alignment audit…"):
            try:
                agent = BrandAlignmentAgent(openai_client=openai_client)
                alignment_report, brand_doc_id = agent.run(
                    profile=st.session_state.profile,
                    strategy_doc_id=st.session_state.strategy_doc_id,
                )
                st.session_state.alignment_report = alignment_report
                st.session_state.brand_doc_id     = brand_doc_id
                st.session_state.stage            = 4
                st.rerun()
            except Exception as exc:
                st.error(f"❌ Brand Alignment Agent error: {exc}")
                st.exception(exc)

# ---------------------------------------------------------------------------
# Stage 4 — Content Agent
# ---------------------------------------------------------------------------
def render_stage_4() -> None:
    st.markdown("## ✍️ Stage 4 — Content Agent")
    st.caption("Generating LinkedIn/X posts, marketing email, and ad copy — "
               "strictly within brand voice and content guardrails.")
    hr()
    render_research_summary()
    render_strategy_summary()
    render_alignment_summary()
    hr()
    if st.button("✍️ Generate Content Package", type="primary"):
        openai_client, _ = resolve_clients()
        with st.spinner("Generating compliant marketing content…"):
            try:
                agent = ContentAgent(openai_client=openai_client)
                content_package, content_doc_id = agent.run(
                    profile=st.session_state.profile,
                    alignment_report=st.session_state.alignment_report,
                    brand_doc_id=st.session_state.brand_doc_id,
                )
                st.session_state.content_package = content_package
                st.session_state.content_doc_id  = content_doc_id
                st.session_state.stage           = 5
                st.rerun()
            except Exception as exc:
                st.error(f"❌ Content Agent error: {exc}")
                st.exception(exc)

# ---------------------------------------------------------------------------
# Stage 5 — Final results dashboard
# ---------------------------------------------------------------------------
def render_results() -> None:
    profile: CompanyProfile      = st.session_state.profile
    package: ContentPackage      = st.session_state.content_package
    report:  BrandAlignmentReport = st.session_state.alignment_report

    st.markdown(f"## ✅ Pipeline Complete — {profile.company_name}")
    hr()

    tab_posts, tab_email, tab_ads, tab_brand, tab_strategy, tab_research = st.tabs([
        "📱 Social Posts",
        "✉️ Email",
        "📣 Ad Copy",
        "🎨 Brand Alignment",
        "🗺️ GTM Strategy",
        "📊 Research",
    ])

    # ── Social Posts ─────────────────────────────────────────────────────────
    with tab_posts:
        st.markdown("### LinkedIn / X Posts")
        st.caption("Three brand-compliant, guardrail-verified posts for Middle East B2B audiences.")
        for i, post in enumerate(package.linkedin_x_posts, 1):
            st.markdown(
                f'<div class="post-card"><div class="platform-tag">'
                f'Post {i} — {post.platform} · {post.post_type}</div></div>',
                unsafe_allow_html=True,
            )
            st.markdown(f"**🪝 Hook**\n\n{post.hook}")
            st.markdown(f"**📝 Body**\n\n{post.body}")
            st.markdown(f"**🎯 CTA**\n\n{post.call_to_action}")
            if post.hashtags:
                st.markdown(" ".join(f"`{h}`" for h in post.hashtags))
            full = f"{post.hook}\n\n{post.body}\n\n{post.call_to_action}"
            if post.hashtags:
                full += "\n\n" + " ".join(post.hashtags)
            with st.expander(f"📋 Copy Post {i} — plain text"):
                st.text_area("", value=full, height=160,
                             label_visibility="collapsed", key=f"copy_post_{i}")
            st.divider()

    # ── Email ─────────────────────────────────────────────────────────────────
    with tab_email:
        email = package.marketing_email
        st.markdown("### Marketing Email Draft")
        cm, cp = st.columns([1, 2])
        with cm:
            st.markdown(f"**Subject:** {email.subject_line}")
            st.markdown(f"**Preview:** *{email.preview_text}*")
            st.markdown(f"**CTA:** `{email.primary_cta}`")
        with cp:
            body_html = "".join(f"<p>{p}</p>" for p in email.body_paragraphs)
            st.markdown(
                f'<div class="email-preview">'
                f'<div class="email-subject">{email.subject_line}</div>'
                f'<div class="email-preview-text">{email.preview_text}</div>'
                f"<p>{email.greeting}</p>{body_html}"
                f'<a class="email-cta" href="#">{email.primary_cta}</a>'
                f"<br><br><p>{email.sign_off}</p></div>",
                unsafe_allow_html=True,
            )
        plain = (f"Subject: {email.subject_line}\nPreview: {email.preview_text}\n\n"
                 f"{email.greeting}\n\n" + "\n\n".join(email.body_paragraphs)
                 + f"\n\n{email.primary_cta}\n\n{email.sign_off}")
        with st.expander("📋 Copy Email — plain text"):
            st.text_area("", value=plain, height=220,
                         label_visibility="collapsed", key="copy_email")

    # ── Ad Copy ───────────────────────────────────────────────────────────────
    with tab_ads:
        st.markdown("### Ad Copy Sets")
        st.caption("Ready for LinkedIn Sponsored Content and Google Search campaigns.")
        for i, ad in enumerate(package.ad_copy_sets, 1):
            st.markdown(
                f'<div class="ad-card"><div class="platform-tag">'
                f'Ad Set {i} — {ad.placement}</div></div>',
                unsafe_allow_html=True,
            )
            st.markdown(f"**Headline:** {ad.headline}")
            st.markdown(f"**Body:** {ad.body_copy}")
            st.markdown(f"**CTA Button:** `{ad.cta_button}`")
            ad_text = f"Headline: {ad.headline}\nBody: {ad.body_copy}\nCTA: {ad.cta_button}"
            with st.expander(f"📋 Copy Ad Set {i}"):
                st.text_area("", value=ad_text, height=100,
                             label_visibility="collapsed", key=f"copy_ad_{i}")
            st.divider()

    # ── Brand Alignment ───────────────────────────────────────────────────────
    with tab_brand:
        st.markdown("### Brand Alignment Report")
        st.caption(f"Brand Alignment Doc ID: `{st.session_state.brand_doc_id}`")
        st.markdown(f"**Alignment Summary**\n\n{report.alignment_summary}")
        st.divider()
        st.markdown(f"**Brand Voice Guidelines**\n\n{report.brand_voice_guidelines}")
        st.divider()
        st.markdown("**Aligned Value Proposition**")
        st.info(report.aligned_value_proposition)
        st.divider()
        st.markdown("**Content Guardrails Applied to All Generated Content**")
        for g in report.content_guardrails:
            st.markdown(
                f'<div class="guardrail-item">🛡️ {g}</div>',
                unsafe_allow_html=True,
            )

    # ── GTM Strategy ──────────────────────────────────────────────────────────
    with tab_strategy:
        st.caption(f"Strategy Doc ID: `{st.session_state.strategy_doc_id}`")
        st.markdown(st.session_state.gtm_strategy)

    # ── Research ──────────────────────────────────────────────────────────────
    with tab_research:
        st.caption(f"Research Doc ID: `{st.session_state.research_doc_id}`")
        render_research_summary()

    hr()
    st.markdown(
        f"**Session IDs** &emsp; "
        f"Research: `{st.session_state.research_doc_id}` &emsp; "
        f"Strategy: `{st.session_state.strategy_doc_id}` &emsp; "
        f"Brand: `{st.session_state.brand_doc_id}` &emsp; "
        f"Content: `{st.session_state.content_doc_id}`"
    )

# ---------------------------------------------------------------------------
# Main router
# ---------------------------------------------------------------------------
def main() -> None:
    render_sidebar()

    st.markdown(
        "<h1 style='font-size:2rem;font-weight:800;margin-bottom:4px'>🧠 MarketMind AI</h1>"
        "<p style='color:#64748B;margin-top:0'>Agentic Marketing & Market Research · "
        "Middle East GTM Intelligence Platform</p>",
        unsafe_allow_html=True,
    )

    stage    = st.session_state.stage
    substage = st.session_state.substage

    if stage == 1:
        if substage == "form":
            render_form()
        elif substage == "hitl":
            render_hitl()
        elif substage == "running":
            run_research_pipeline()
    elif stage == 2:
        render_stage_2()
    elif stage == 3:
        render_stage_3()
    elif stage == 4:
        render_stage_4()
    elif stage >= 5:
        render_results()


if __name__ == "__main__":
    main()